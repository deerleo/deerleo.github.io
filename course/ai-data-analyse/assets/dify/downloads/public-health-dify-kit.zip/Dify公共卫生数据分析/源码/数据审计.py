import csv
import io
import json
import math

FIELDS = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
          'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal', 'num']
# 构建 DSL 时，以本地已校验的 UCI 原始数据替换该常量。
BUILTIN_CSV = '__BUILTIN_UCI_CLEVELAND_CSV__'
SOURCE_URL = 'https://archive.ics.uci.edu/dataset/45/heart+disease'
RAW_SHA256 = 'a74b7efa387bc9d108d7d0115d831fe9b414b29ae7124f331b622b4efa0427c8'


def main(csv_text: str = '') -> dict:
    empty = {'status': 'error', 'rows_json': '[]', 'audit_json': '{}', 'error': ''}
    try:
        if csv_text is not None and not isinstance(csv_text, str):
            raise ValueError('csv_text 必须是文本。')
        text = (csv_text or '').strip().lstrip('\ufeff')
        builtin = not bool(text)
        text = BUILTIN_CSV if builtin else text
        if len(text) > 150000:
            raise ValueError('CSV 文本超过15万字符，请先缩小数据集。')
        table = [row for row in csv.reader(io.StringIO(text)) if any(x.strip() for x in row)]
        if not table:
            raise ValueError('未检测到有效数据行。')
        first = [x.strip().lower() for x in table[0]]
        # 官方 processed.cleveland.data 无表头；自定义CSV须使用标准表头。
        has_header = 'age' in first or 'num' in first
        if has_header:
            if len(set(first)) != len(first):
                raise ValueError('CSV 表头存在重复字段。')
            missing_columns = [x for x in FIELDS if x not in first]
            if missing_columns:
                raise ValueError('缺少必需字段：' + ', '.join(missing_columns))
            indices = [first.index(x) for x in FIELDS]
            source_rows = table[1:]
            row_offset = 2
            ignored_columns = [x for x in first if x not in FIELDS]
            width = len(first)
        else:
            if len(table[0]) != 14:
                raise ValueError('CSV 需要标准14列表头；官方无表头文件须恰好14列。')
            indices = list(range(14))
            source_rows = table
            row_offset = 1
            ignored_columns = []
            width = 14
        if not 2 <= len(source_rows) <= 1000:
            raise ValueError('教学版接受2–1000条数据记录。')

        categories = {'sex': [0, 1], 'cp': [1, 2, 3, 4], 'fbs': [0, 1],
                      'restecg': [0, 1, 2], 'exang': [0, 1], 'slope': [1, 2, 3],
                      'ca': [0, 1, 2, 3], 'thal': [3, 6, 7], 'num': [0, 1, 2, 3, 4]}
        missing = {x: 0 for x in FIELDS}
        complete, invalid, missing_row_numbers = [], [], []
        duplicate_count, seen = 0, set()
        for line, raw in enumerate(source_rows, row_offset):
            if len(raw) != width:
                invalid.append('第%d行列数为%d，预期%d' % (line, len(raw), width))
                continue
            record, row_missing, bad = {}, False, False
            normalized = tuple(raw[i].strip() for i in indices)
            if normalized in seen:
                duplicate_count += 1
            seen.add(normalized)
            for col, index in zip(FIELDS, indices):
                value = raw[index].strip()
                if value.lower() in ('', '?', 'na', 'n/a', 'null', 'nan'):
                    missing[col] += 1
                    row_missing = True
                    continue
                try:
                    number = float(value)
                    if not math.isfinite(number):
                        raise ValueError('非有限数值')
                    if col in categories and number not in categories[col]:
                        raise ValueError('编码须属于' + str(categories[col]))
                    if col == 'age' and not 0 < number <= 120:
                        raise ValueError('年龄须大于0且不超过120')
                    if col in ('trestbps', 'chol', 'thalach') and not 0 < number <= 10000:
                        raise ValueError('须为正值且不超过教学数值上限10000')
                    if col == 'oldpeak' and not 0 <= number <= 100:
                        raise ValueError('须在教学数值范围0–100内')
                    record[col] = number
                except (ValueError, OverflowError):
                    invalid.append('第%d行字段%s数值或编码不符合数据契约' % (line, col))
                    bad = True
            if row_missing:
                missing_row_numbers.append(line)
            if not row_missing and not bad:
                record['disease'] = int(record['num'] > 0)
                complete.append(record)
        # 不把坏编码静默当成缺失剔除；明确退回修正。
        if invalid:
            raise ValueError('数据审计未通过：' + '；'.join(invalid[:8]) +
                             ('；其余%d处略' % (len(invalid) - 8) if len(invalid) > 8 else ''))
        if len(complete) < 2:
            raise ValueError('完整案例少于2条，无法完成当前分析。')
        audit = {
            'source': '内置 UCI Cleveland 公开历史数据' if builtin else '用户粘贴CSV，来源与许可待用户确认',
            'source_url': SOURCE_URL if builtin else '',
            'raw_sha256': RAW_SHA256 if builtin else '',
            'input_rows': len(source_rows), 'retained_rows': len(complete),
            'removed_missing_rows': len(missing_row_numbers),
            'missing_by_column': missing, 'duplicate_rows_retained': duplicate_count,
            'ignored_columns': ignored_columns,
            'missing_strategy': '14个必需字段的完整案例分析；不插补；重复记录仅标记、不自动删除',
            'label_mapping': 'num=0 → 阴性；num=1/2/3/4 → 阳性',
            'age_group_rule': '年龄≥55岁 vs <55岁；教学分组，不是诊断阈值',
            'row_count_note': '所有后续统计均使用同一份完整案例数据',
        }
        return {'status': 'ok', 'rows_json': json.dumps(complete, ensure_ascii=False, allow_nan=False),
                'audit_json': json.dumps(audit, ensure_ascii=False, allow_nan=False), 'error': ''}
    except (ValueError, TypeError, csv.Error) as exc:
        empty['error'] = str(exc)
        return empty
